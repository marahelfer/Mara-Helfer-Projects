package uk.ac.nulondon;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import javax.imageio.ImageIO;

public final class App {

    String originalFilepath;
    Scanner scan;
    Image currentImage;
    Pixel lastShownSeam;
    private App() {
        this.scan = new Scanner(System.in);
    }

    //Prints menu of options to the user
    public static void printMenu() {
        System.out.println("Please make a selection");
        System.out.println("b) Show the Bluest seam");
        System.out.println("e) Show the seam with the lowest energy");
        System.out.println("d) Delete the last shown seam from the Image");
        System.out.println("u) Undo; reinserting the previously deleted seam");
        System.out.println("q) Quit");
        System.out.println(" ");
    }

    public void saveImageToPath(String filepath, BufferedImage image){
        File newFile = new File(filepath);
        try {
            ImageIO.write(image, "png", newFile);
            System.out.println("Image stored as " + filepath);
        }
        catch(Exception e){
            System.out.println("Something went wrong while trying to save the image to disc with filepath" + filepath + ".");
        }
    }

    public int printResponse(char selection, int version,
                             String folderPathPath, String fileType) {

        char confirm = 0;
        switch (selection) {

            //case "b"; if user selects the bluest seam
            case 'b':

                //TODO fix type of bluest seam
                Pixel bluestSeam = currentImage.findSeam(true);
                //saves myImage with the bluest seam highlighted
                BufferedImage highlightImageBlue = currentImage.toBufferedImage();
                currentImage.highlightBufferedImage(highlightImageBlue, bluestSeam, new Color(0, 0, 255));
                saveImageToPath("temp_image"+ version + "." + fileType, highlightImageBlue);
                lastShownSeam = bluestSeam;
                break;

            //case "e"; if the user wants to show the seam with the lowest energy
            case 'e':

                Pixel lowestEnergySeam = currentImage.findSeam(false);
                BufferedImage highlightImageRed = currentImage.toBufferedImage();
                currentImage.highlightBufferedImage(highlightImageRed, lowestEnergySeam, new Color(255, 0, 0));
                //saves image with the lowest seam highlighted
                saveImageToPath("temp_image"+ version + "." + fileType, highlightImageRed);
                lastShownSeam = lowestEnergySeam;
                break;

                //case 'd' if the user wants to delete the most recently shown seam
            case 'd':
                System.out.println("Are you sure you want to delete the most recently shown seam?");
                confirm = this.scan.next().toLowerCase().charAt(0);
                if (confirm == 'y') {
                    if(lastShownSeam == null){
                        System.out.println("You haven't yet highlighted a seam, going back to main menu.");
                        break;
                    }
                    System.out.println("Removing most recently shown seam");
                    currentImage.removeSeam(lastShownSeam);
                    lastShownSeam = null;
                    saveImageToPath("temp_image"+ version + "." + fileType, currentImage.toBufferedImage());
                }else{
                    System.out.println("Not removing, going back to main menu.");
                }
                break;

            //case "u"; if the user selects undo
            case 'u':
                if(currentImage.getSeamsLength() == 0){
                    System.out.println("Can't undo, you haven't deleted anything yet.");
                    break;
                }
                currentImage.undo();
                saveImageToPath("temp_image"+ version + "." + fileType, currentImage.toBufferedImage());
                break;

            //if user selects that they want to quit out of the menu
            case 'q':
                System.out.println("Are you sure you want to quit");
                confirm = this.scan.next().toLowerCase().charAt(0);

                if (confirm == 'y') {
                    System.out.println("Quitting, Thanks for Playing!");
                    //exits system to quit out of terminal
                    System.exit(0);
                } else {
                    System.out.println("Not Quitting, going back to main menu.");
                }
                break;

            //default returns when user input does not match one of the case statements
            default:
                System.out.println("That is not a valid option.");
                break;

        }
        //returns the version of the last version of the Image save
        return version;
    }


    public void initializeImage(){
        //get the filepath from the user
        System.out.println("Please enter the filepath of the image: ");
        BufferedImage image;
        //make sure the filepath is *actually* a png file that we can read
        while (true) {
            originalFilepath = scan.nextLine();
            // Code to read image into an image buffer
            try {
                File originalFile = new File(originalFilepath);
                image = ImageIO.read(originalFile);
                break;
            } catch (Exception e) {
                System.out.println("Invalid file at " + originalFilepath + ". Please enter a different filepath:");
            }
        }
        //turn image into a ComputedPixelImage
        //we don't have to worry about it being null because the try/catch would catch that
        //we also know it's a valid BufferedImage because that would be caught as well
        currentImage = new Image(image);
    }

    //TODO double undo ????
    //Main Method
    public static void main(String[] args) {
        App myApp = new App();
        myApp.initializeImage();
        int acc = 0;
        while(true){
            printMenu();
            String response = myApp.scan.next();
            myApp.printResponse(response.toCharArray()[0], acc, myApp.originalFilepath, "png");
            acc += 1;
        }

    }
}
