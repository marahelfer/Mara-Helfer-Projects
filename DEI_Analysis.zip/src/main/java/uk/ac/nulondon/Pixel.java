package uk.ac.nulondon;
import java.awt.Color;

public class Pixel {
    private Pixel up;
    private Pixel down;
    private Pixel left;
    private Pixel right;
    private Color colour;
    private double energy;
    private double seamWeight;
    private Pixel seamPrevious;

    public Pixel(Color c) {
        this.colour = c;
        this.up = null;
        this.down = null;
        this.right = null;
        this.left = null;
    }

    //checks if there is an up or a down seam
    public boolean hasUp(){
        return this.getUp() != null;
    }
    public boolean hasDown(){
        return this.getDown() != null;
    }
    public boolean hasTopRight(){
        return this.getTopRight() != null;
    }
    public boolean hasTopLeft(){
        return this.getTopLeft() != null;
    }
    public boolean hasBottomRight(){
        return this.getBottomRight() != null;
    }
    public boolean hasBottomLeft(){
        return this.getBottomLeft() != null;
    }
    public boolean hasLeft(){
        return this.getLeft() != null;
    }
    public boolean hasRight(){
        return this.getRight() != null;
    }

   //Checks if there is a seam diagonally
    //if not returns null
    public Pixel getTopRight(){
        return this.up != null ? this.up.right: null;
    }

    public Pixel getTopLeft(){
        return this.up != null ? this.up.left: null;
    }

    public Pixel getBottomRight(){
        return this.down != null ? this.down.right: null;
    }

    public Pixel getBottomLeft(){
        return this.down != null ? this.down.left: null;
    }

    public Pixel getUp() {
        return up;
    }

    //GETTERS
    public Pixel getDown() {
        return down;
    }

    public Pixel getLeft() {
        return left;
    }

    public Pixel getRight() {
        return right;
    }

    public Color getColour(){
        return colour;
    }
    public double getWeight(){
        return seamWeight;
    }
    public Pixel getSeamPrevious(){
        return seamPrevious;
    }

    //SETTERS
    public void setUp(Pixel pixel) {
        up = pixel;
    }

    public void setDown(Pixel pixel) {
        down = pixel;
    }

    public void setLeft(Pixel pixel) {
        left = pixel;
    }

    public void setRight(Pixel pixel) {
        right = pixel;
    }

    public void setColour(Color colour){
        this.colour = colour;
    }

    //The brightness of a pixel is the average of the RGB values of the color of a given pixel.
    public double getBrightness() {
        return ((this.colour.getRed() + this.colour.getBlue() + this.colour.getGreen()) / 3.0);
    }

    public int getBlueScore(){
        return this.colour.getBlue();
    }

    //calculates the amount of energy in
    public void calculateEnergy() {
        //defining each seam of brightness
        double brightnessA = this.hasTopLeft() ? this.getTopLeft().getBrightness(): this.getBrightness();
        double brightnessB = this.hasUp() ? this.getUp().getBrightness(): this.getBrightness();
        double brightnessC = this.hasTopRight() ? this.getTopRight().getBrightness(): this.getBrightness();
        double brightnessD = this.hasLeft() ? this.getLeft().getBrightness(): this.getBrightness();
        double brightnessF = this.hasRight() ? this.getRight().getBrightness(): this.getBrightness();
        double brightnessG = this.hasBottomLeft() ? this.getBottomLeft().getBrightness(): this.getBrightness();
        double brightnessH = this.hasDown() ? this.getDown().getBrightness(): this.getBrightness();
        double brightnessI = this.hasBottomLeft() ? this.getBottomLeft().getBrightness(): this.getBrightness();
        //Calculating the energy
        double horizontalEnergy = ((brightnessA + 2 * (brightnessD) + brightnessG) - (brightnessC + 2 * (brightnessF) + brightnessI));
        double verticalEnergy = ((brightnessA + 2 * (brightnessB) + brightnessC) - (brightnessG + 2 * (brightnessH) + brightnessI));
        this.energy = (Math.sqrt(Math.pow(horizontalEnergy, 2) + Math.pow(verticalEnergy, 2)));
    }

    //calculates the weight
    public void calculateWeight(boolean bluest){
        if(up != null){
            Pixel topLeft = up.getLeft();
            Pixel topRight = up.getRight();
            seamWeight = up.seamWeight;
            seamPrevious = up;
            if(topLeft != null && topLeft.seamWeight > seamWeight){
                seamWeight = topLeft.seamWeight;
                seamPrevious = topLeft;
            }
            if(topRight != null && topRight.seamWeight > seamWeight){
                seamWeight = topRight.seamWeight;
                seamPrevious = topRight;
            }
            seamWeight += bluest ? colour.getBlue() : energy;
        }
        else{
            seamWeight = bluest ? colour.getBlue() : energy;
        }
    }

    public double getEnergy(){
        return this.energy;
    }
}
