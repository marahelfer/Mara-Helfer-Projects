package uk.ac.nulondon;

import java.util.LinkedList;

public class Seam {
    private int startRow;
    private int startCol;
    private double weight;
    private LinkedList<Pixel> pixels;

    public Seam(int startRow, int startCol, Pixel pixel){
        this.startRow = startRow;
        this.startCol = startCol;
        this.weight = 0;
        this.pixels = new LinkedList<>();
        this.pixels.add(pixel);
    }

    public int getStartRow(){
        return startRow;
    }
    public int getStartCol(){
        return startCol;
    }
    public LinkedList<Pixel> getPixels(){
        return pixels;
    }

    //gets the blue sum of the pixels in Pixel
    public double getWeight(){
        return weight;
    }

    //gets the sum of the energy values for the pixels in Pixel
    public int getEnergySum(){
        int energySum = 0;
        for(Pixel pixel : pixels){
            energySum += pixel.getEnergy();
        }
        return energySum;
    }

    public int getSize(){
        return pixels.size();
    }

    public Pixel getStart(){
        return pixels.getFirst();
    }

    public Pixel getEnd(){
        return pixels.getLast();
    }

    public void addPixel(Pixel pixel){
        this.pixels.add(pixel);
    }

    //Creates a copy of the seam and adds a pixel to the end of the copy
    public Seam addToCopy(Pixel pixel){
        Seam cloneSeam = new Seam(this.startRow, this.startCol, this.getStart());
        for (int i = 1; i < this.pixels.size(); i ++){
            cloneSeam.addPixel(pixels.get(i));
        }
        cloneSeam.addPixel(pixel);
        return cloneSeam;
    }

}
