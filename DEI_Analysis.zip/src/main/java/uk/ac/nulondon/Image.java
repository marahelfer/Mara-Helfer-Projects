package uk.ac.nulondon;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Image {
    private Pixel topLeft;
    private int width;
    private int height;
    private List<Pixel> seams;

    public int getWidth(){
        return width;
    }

    public int getHeight(){
        return height;
    }

    public void saveImage(String fileName) {
        //gets the image dimension;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        Pixel pointer = topLeft;
        for(int y = 0; y < height; y++){
            Pixel pixel = pointer;
            for(int x = 0; x < width; x++){
                //do whatever
                image.setRGB(x, y, pixel.getColour().getRGB());
                pixel = pixel.getRight();
            }
            pointer = pointer.getDown();
        }

       /* int width = values.get(0).size();
        int height = values.size();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for(int y = 0; y < height; y++){
            for(int x = 0; x < width; x++){
                image.setRGB(x, y, values.get(y).get(x).getColor().getRGB());
            }
        }*/

        File outputFile = new File(fileName);
        try{
            ImageIO.write(image, "png",outputFile);
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    //able to edit the buffered image based on the seam its given
    public BufferedImage highlightBufferedImage(BufferedImage image, Pixel seam, Color c){
        while(seam != null){
            int[] coords = getCoords(seam);
            image.setRGB(coords[0], coords[1], c.getRGB());
            seam = seam.getSeamPrevious();
        }
        return image;
    }

    public BufferedImage toBufferedImage(){
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Pixel pointer = topLeft;
        for(int y = 0; y < height; y++){
            Pixel pixel = pointer;
            for(int x = 0; x < width; x++){
                image.setRGB(x, y, pixel.getColour().getRGB());
                pixel = pixel.getRight();
            }
            pointer = pointer.getDown();
        }
        return image;
    }

    public Image(BufferedImage original){
        seams = new ArrayList<>();
        this.height = original.getHeight();
        this.width = original.getWidth();
        Pixel topPixel = null;
        Pixel leftPixel = null;
        for(int y = 0; y < height; y++){
            for(int x = 0; x < width; x++){
                Pixel pixel = new Pixel(new Color(original.getRGB(x, y)));
                if(x == 0 && y == 0){
                    this.topLeft = pixel;
                }
                if(leftPixel != null){
                    leftPixel.setRight(pixel);
                    pixel.setLeft(leftPixel);
                }
                if(topPixel != null){
                    topPixel.setDown(pixel);
                    pixel.setUp(topPixel);
                }
                if(x != width - 1){
                    leftPixel = pixel;
                    if(y != 0){
                        topPixel = pixel.getUp().getRight();
                    }
                }
                else{
                    leftPixel = null;
                    topPixel = pixel;
                    while(true){
                        if(topPixel.getLeft() == null){
                            break;
                        }
                        topPixel = topPixel.getLeft();
                    }
                }
            }
        }
    }

    //finds the bluest seam in a collection of pixels
//    public Seam getBluestSeam(Image image) {
//        ArrayList<Pixel> topRow = image.getTopRow();
//        ArrayList<Seam> currentSeams = new ArrayList<>();
//
//        int column = 0;
//        for (Pixel pixel : topRow){
//            currentSeams.add(new Seam(0, column, pixel));
//            column += 1;
//        }
//        ArrayList<Pixel> currentRow = topRow;
//
//        for (int row = 1; row < image.getHeight(); row++){
//            ArrayList<Pixel> newRow = new ArrayList<>();
//            for(Pixel pixel : currentRow){
//                newRow.add(pixel.getDown());
//            }
//            currentRow = newRow;
//            ArrayList<Seam> oldSeams = currentSeams;
//            currentSeams = new ArrayList<>();
//            for (int col = 0; col < image.getWidth(); col++){
//                Pixel currentPixel = currentRow.get(col);
//                //finding blue sum of the seams ending in top left, top blue, or top right
//                int topLeftBlue = col - 1 >= 0 ? oldSeams.get(col - 1).getBlueSum(): -1;
//                int topBlue = oldSeams.get(col).getBlueSum();
//                int topRightBlue = col + 1 < oldSeams.size() ? oldSeams.get(col + 1).getBlueSum(): -1;
//                //finds the bluest by comparing to the neighbours
//                if (topLeftBlue > topBlue && topLeftBlue > topRightBlue){
//                    currentSeams.add(oldSeams.get(col - 1).addToCopy(currentPixel));
//                }
//                else if(topBlue > topLeftBlue && topBlue > topRightBlue){
//                    currentSeams.add(oldSeams.get(col).addToCopy(currentPixel));;
//                }
//                else{
//                    currentSeams.add(oldSeams.get(col + 1).addToCopy(currentPixel));;
//                }
//            }
//        }
//        int maxBlue = 0;
//        for (Seam seam: currentSeams){
//            maxBlue = Math.max(maxBlue, seam.getBlueSum());
//        }
//        Seam bluestSeam = null;
//        for (Seam seam: currentSeams){
//            if(seam.getBlueSum() == maxBlue){
//                bluestSeam = seam;
//            }
//        }
//        return bluestSeam;
//    }

    public Pixel findSeam(boolean bluest){

        Pixel pointer = topLeft;
        for(int y = 0; y < height; y++){
            Pixel pixel = pointer;
            for(int x = 0; x < width; x++){
                if(!bluest){
                    pixel.calculateEnergy();
                }
                pixel.calculateWeight(bluest);
                pixel = pixel.getRight();
            }
            pointer = pointer.getDown();
        }

        //okay now the weight has been calculated for every pixel
        //need to find the lowest-value seam
        //go to the last row and check every pixel
        pointer = getPixelAt(0, height-1);
        Pixel lowestSeam = pointer;
        for(int x = 0; x < width; x++){
            if(pointer.getWeight() > lowestSeam.getWeight()){
                lowestSeam = pointer;
            }
            pointer = pointer.getRight();
        }

        return lowestSeam;
    }

    public void removeSeam(Pixel endOfSeam){
        Pixel iter = endOfSeam;
        while(iter != null){
            //fix the references for left and right neighbors
            if(iter.getLeft() != null){
                iter.getLeft().setRight(iter.getRight());
            }
            if(iter.getRight() != null){
                iter.getRight().setLeft(iter.getLeft());
            }
            Pixel nextToRemove = iter.getSeamPrevious();
            if(iter.getUp() != null){
                if(iter.getUp().getLeft() == nextToRemove){
                    iter.getUp().setDown(iter.getLeft());
                    iter.getLeft().setUp(iter.getUp());
                }
                else if(iter.getUp().getRight() == nextToRemove){
                    iter.getUp().setDown(iter.getRight());
                    iter.getRight().setUp(iter.getUp());
                }
            }
            if(iter == topLeft){
                topLeft = iter.getRight();
                //there *should* always be a right node, else we'd kick the user for trying to delete the whole image
            }
            iter = iter.getSeamPrevious();
        }
        width -= 1;
        seams.add(endOfSeam);
        //we *should* be done after this. hopefully. maybe.
    }

    public int getSeamsLength(){
        return seams.size();
    }

    public void undo(){
        Pixel p = seams.removeLast();
        //get the lowest-left pixel
        Pixel pointer = getPixelAt(0, height-1);
        for(int y = height-1; y >= 0; y--){
            Pixel pixel = pointer;

            //if we're on the far left, then just set the first pixel's left neighbor to us
            if(p.getLeft() == null){
                pixel.setLeft(p);
            }
            //otherwise, we need to iterate until we find our left neighbor, then insert ourselves between it and its right neighbor
            else{
                while(pixel != null){
                    if(pixel == p.getLeft()){
                        if(pixel.getRight() != null) {
                            pixel.getRight().setLeft(p);
                        }
                        pixel.setRight(p);
                        break;
                    }
                    pixel = pixel.getRight();
                }
            }
            //we've fixed the left and right, now for top and bottom
            //assume the bottom row has been successfully created
            if(y != height-1) {
                if (p.getRight() != null) {
                    p.getRight().getDown().getLeft().setUp(p);
                } else {
                    p.getLeft().getDown().getRight().setUp(p);
                }
            }

            //the top row may not be successfully made
            if(y != 0){
                //need to check the top right and left diagonals
                //to see which link to reforge
                if(p.getRight() != null){
                    if(p.getRight().getUp() == p.getUp()){
                        p.getRight().getUp().setDown(p);
                    }
                }
                if(p.getLeft() != null){
                    if(p.getLeft().getUp() == p.getUp()){
                        p.getLeft().getUp().setDown(p);
                    }
                }
            }

            //make sure we keep the topLeft reference as the *actual* top left node
            if(y == 0 && p.getLeft() == null){
                topLeft = p;
            }

            //need to iterate *upwards*
            p = p.getSeamPrevious();
            pointer = pointer.getUp();
        }
        width += 1;
    }

    //NOTE: when iterating over the entire image, best to use a different method. This is
    //good for when you only need one pixel.
    public Pixel getPixelAt(int x, int y){
        if(x < width && y < height && x >= 0 && y >= 0){
            Pixel pointer = topLeft;
            for(int iter = 0; iter < x; iter++){
                pointer = pointer.getRight();
            }
            for(int iter = 0; iter < y; iter++){
                pointer = pointer.getDown();
            }
            return pointer;
        }
        return null;
    }

    public int[] getCoords(Pixel p){
        Pixel pointer = topLeft;
        for(int y = 0; y < height; y++){
            Pixel pixel = pointer;
            for(int x = 0; x < width; x++){
                if(pixel == p){
                   return new int[]{x, y};
                }
                pixel = pixel.getRight();
            }
            pointer = pointer.getDown();
        }
        return new int[]{-1, -1};
    }

    //finds the top row of the image
    //the possible start points for the seam we build
    private ArrayList<Pixel> getTopRow() {
        Pixel current = topLeft;
        ArrayList<Pixel> topRow = new ArrayList<>();
        while(current != null){
            topRow.add(current);
            current = current.getRight();
        }
        return topRow;
    }

    //Highlights lowest energy in RED
    public void highlight(Pixel pixel, Color c){
        while( pixel != null){
            pixel.setColour(c);
            pixel = pixel.getSeamPrevious();
        }
    }


}
